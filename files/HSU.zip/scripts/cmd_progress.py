# -*- coding: UTF-8 -*-

import time
import pickle
import subprocess
from cmd_upgrade import CmdUpgrade

'''
###############################################################################
# 调用：hsu progress <task-id>
# 输入：
#   task-id 由升级驱动返回的task-id
# 输出：
#   {
#       "<name>":{
#           "state":"<TaskState>",
#           "percent":<value>
#       },
#       ...
#   }
#   percent 当前升级的百分比，0-100
###############################################################################
'''

class CmdProgress(CmdUpgrade):
    def _getPercent(self, name, taskid, max_waitsec=7200):
        tbeg = time.time()
        retv = {"name":name, "state":"Exception", "percent":100}
        while True:
            if (time.time() - tbeg) >= max_waitsec:
                break
            resp = self.client.get_resource(taskid, timeout=100)
            # Result as below:
            #   {'status_code': 200, 'resource': {u'@odata.type': u'#Task.v1_0_2.Task', u'Name': u'Upgarde Task',
            #   u'TaskState': u'Completed', u'Messages': {u'@odata.type': u'/redfish/v1/$metadata#MessageRegistry.1.0.0.MessageRegistry',
            #   u'Severity': u'OK', u'MessageId': u'iBMC.1.0.FirmwareUpgradeComponent', u'RelatedProperties': [],
            #   u'Message': u'Upgrading the BIOS.', u'Resolution': u'Wait until the upgrade is complete.',
            #   u'MessageArgs': [u'BIOS']}, u'@odata.id': u'/redfish/v1/TaskService/Tasks/2',
            #   u'@odata.context': u'/redfish/v1/$metadata#TaskService/Tasks/Members/$entity',
            #   u'TaskStatus': u'OK', u'StartTime': u'2018-06-26T04:52:18+00:00', u'EndTime': u'2018-06-26T04:52:26+00:00',
            #   u'Id': u'2', u'Oem': {u'Huawei': {u'TaskPercentage': u'100%'}}}, 'headers': {'content-length': '646', ...}}
            if (None == resp):
                # Network not ready? need try again and again ...
                time.sleep(1)
                continue
            print(resp)
            if 200 != resp["status_code"]:# or "Exception" == resp['resource']['TaskState']:
                break
            if "Completed" == resp['resource']['TaskState']:
                retv["state"] = "Completed"
                break
            percent = resp['resource']['Oem']['Huawei']['TaskPercentage']
            percent = percent.replace("%", "")
            progress = int(percent)
            if (progress >= 100):
                progress = 99
            retv["state"] = resp['resource']['TaskState']
            retv["percent"] = progress
            break
        return retv

    def run(self):
        if len(self.args.options) < 1:
            self._error(1, "Usage: hsu progress <task-id>")
            return
        taskid = self.args.options[0]
        task_finished, reset_os = self.get_task_progress(taskid)
        if task_finished and reset_os:
            self._flush()
            # Need reboot X86 OS for active inband upgrades
            print("Rebooting X86 OS, need remove it under release mode!!!")
            # subprocess.call("reboot >/dev/null 2>/dev/null", shell=True)
            pass

    def get_task_progress(self, taskid):
        # Load cached tasks info
        try:
            with open("hsu_upgrade.dat", "rb") as file:
                data = pickle.load(file)
            if data["taskid"] != taskid:
                raise Exception("Invalid taskid")
        except:
            self._error(2, "Invalid taskid, need run verify and upgrade again")
            return
        # Prepare result data
        map = {}
        finished = True
        # Add finished items
        for item in data["done"]:
            map[item["name"]] = {"state": item["state"], "percent": 100}
        # Retrieve current upgrading item state and percentage
        item = self._getPercent(data["progname"], data["progid"])
        map[item["name"]] = {"state": item["state"], "percent": item["percent"]}
        if item["percent"] >= 100:
            data["done"].append(item)
            while len(data["data"]["outband"]) > 0:
                elist = {}
                item = data["data"]["outband"][0]
                data["data"]["outband"].remove(item)
                taskid = self.upgradeOutbandFW(item, elist)
                if None == taskid:
                    item = {"name": item["name"], "state": "Exception",
                            "percent": 100}
                    data["done"].append(item)
                    map[item["name"]] = {"state": item["state"],
                                         "percent": item["percent"]}
                    continue
                finished = False
                data["progid"] = taskid
                data["progname"] = item["name"]
                map[item["name"]] = {"state": "Running", "percent": 0}
                break
        else:
            finished = False
        for item in data["data"]["outband"]:
            map[item["name"]] = {"state": "Pending", "percent": 0}
        if finished:
            subprocess.call("rm -rf tmp >/dev/null 2>/dev/null", shell=True)
            subprocess.call("rm -rf hsu_upgrade.dat >/dev/null 2>/dev/null",
                            shell=True)
        else:
            with open("hsu_upgrade.dat", "wb") as file:
                pickle.dump(data, file)
        self.result["data"] = map
        return finished, data["resetos"]
