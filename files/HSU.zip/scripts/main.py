#!/usr/bin/python
# -*- coding: UTF-8 -*-

import os
import sys
import signal
import argparse

__version__ = '1.0.0'

def doit():
    # ================================================================
    # @Method:  CLI main entry function
    # @Param:   None
    # @Return:  None
    # @Author:  Joson_Zhang
    # ================================================================
    try:
        # Construct argparser and add major command parameters.
        parser = argparse.ArgumentParser(prog='hsu')
        parser.add_argument('-v', '--version', action='version', version="Version: %s" % __version__)
        parser.add_argument('--format', dest="fmt", choices=['json','console'], default="console", help="output format type, should be (json|console)")
        parser.add_argument('command', metavar='command', choices=['verify','upgrade','progress'], help="action command, should be (verify|upgrade|progress)")
        parser.add_argument('options', metavar='options', nargs='*', help="run %(prog)s command for detail help")
        args = parser.parse_args()
        cmd = __import__('cmd_'+args.command)
        cls = getattr(cmd, 'Cmd'+args.command.capitalize())
        obj = cls(args, {"rc":0, "msg":"OK", "data":{}})
        obj.run()
    except KeyboardInterrupt:
        s = signal.signal(signal.SIGINT, signal.SIG_IGN)
        signal.signal(signal.SIGINT, s)

if __name__ == '__main__':
    root = os.path.split(os.path.realpath(__file__))[0]
    os.chdir(root)
    sys.path.insert(1, os.path.join(root, '../redfish'))
    #print(sys.path)
    #print(os.getcwd())
    doit()
