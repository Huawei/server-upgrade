# -*- coding: UTF-8 -*-

import os
import pickle
import subprocess
from cmd_base import CmdBase
from cStringIO import StringIO
from xml.dom.minidom import parseString

'''
###############################################################################
# 调用：hsu verify
# 输入：
#   无
# 输出：
#   {
#       "<driver name>":{
#           "v-use":"<current using version>",
#           "v-max":"<server lastest version>",
#           "vlist":["<version-1>", "<version-2>", ...]
#       },
#       ...
#   }
#   name    驱动名称
#   v-use   当前正在使用的版本
#   v-max   服务器上最新的版本
#   vlist   服务器上可用版本列表
###############################################################################
'''
class CmdVerify(CmdBase):
    '''
    # Read repo baseurl from yum repos.d and replace keywords
    '''
    def _getRepoURL(self):
        baseurl = "http://houp.huawei.com/download/server/Linux/Driver/Redhat/Rhel$releasever/$basearch/current/"
        path = "/etc/yum.repos.d"
        if not os.path.isdir(path):
            path = "/etc/yum/repos.d"
        try:
            with open(path+"/houp.repo", "r") as file:
                while True:
                    s = file.readline().strip()
                    if len(s) <= 0:
                        break
                    items = s.split('=')
                    if len(items) != 2:
                        continue
                    if 'baseurl' != items[0].strip():
                        continue
                    baseurl = items[1].strip()
                    break
            s = baseurl
            v = self._getOsVer()
            s = s.replace("$releasever", v)
            s = s.replace("$basearch", self._getOsArch())
        except:
            s = "http://houp.huawei.com/download/server/Linux/Driver/Redhat/Rhel7.4/x86_64/current/"
        #print(s)
        return s

    '''
    # Read driver_version.cfg file as table, columns as below:
    #   Device, type, vender_id, device_id, Fw_verion, Driver_name, Driver_version, Driver, sub_vendor_id, sub_system_id
    #   type: net/raid
    '''
    def _readCfg(self,path):
        result = []
        with open(path, "rb") as f:
            while True:
                s = f.readline().strip()
                if len(s) <= 0:
                    break
                s = s.replace('\t', ' ')
                while True:
                    s2 = s.replace('  ', ' ')
                    if len(s) == len(s2):
                        break
                    s = s2
                result.append(s.split(' '))
        return result

    '''
    # Read local PCI driver list, content as below:
    #   name: ver, mode, device, vendor, subsystem_device, subsystem_vendor
    '''
    def _getDriverSW(self):
        def _byLsPCI():
            list = {}
            pcis = []
            # list all PCI devices
            p = subprocess.Popen(['lspci', '-D'], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            while p.poll() is None:
                s = p.stdout.readline().strip()
                if len(s) <= 0:
                    continue
                # split lspci output per line, and get first column (PCI driver ID)
                t = s.partition(' ')
                if len(t) <= 0:
                    continue
                pcis.append(t[0])
            for pci in pcis:
                # find PCI driver folder under /sys/devices/ folder
                p = subprocess.Popen(["find", "/sys/devices/", "-name", pci], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
                out,err = p.communicate()
                path = out.replace('\n','')
                if None == path or len(path) <= 0:
                    continue
                item = {"path":path}
                # read device
                try:
                    item["ver"] = self._readID(os.path.join(path, "driver/module/version"))
                    item["mode"] = "driver"
                    item["device"] = self._readID(os.path.join(path, "device"))
                    item["vendor"] = self._readID(os.path.join(path, "vendor"))
                    item["subsystem_device"] = self._readID(os.path.join(path, "subsystem_device"))
                    item["subsystem_vendor"] = self._readID(os.path.join(path, "subsystem_vendor"))
                    link = os.readlink(os.path.join(path, "driver"))
                except(OSError,IOError):
                    continue
                if None == link or len(link) <= 0:
                    continue
                names = os.path.split(link)
                if None == names or len(names) != 2:
                    continue
                list[names[1]] = item
            return list
        def _byListSysDevices():
            list = {}
            p = subprocess.Popen(["find", "/sys/devices/", "-name", "driver"], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            out, err = p.communicate()
            buf = StringIO(out)
            while True:
                s = buf.readline().strip()
                if len(s) <= 0:
                    break
                if not s.startswith("/sys/devices/pci"):
                    continue
                paths = os.path.split(s)
                if (None == paths) or (len(paths) != 2):
                    continue
                path = paths[0]
                item = {"path": path}
                # read device
                try:
                    item["ver"] = self._readID(os.path.join(path, "driver/module/version"))
                    item["mode"] = "driver"
                    item["device"] = self._readID(os.path.join(path, "device"))
                    item["vendor"] = self._readID(os.path.join(path, "vendor"))
                    item["subsystem_device"] = self._readID(os.path.join(path, "subsystem_device"))
                    item["subsystem_vendor"] = self._readID(os.path.join(path, "subsystem_vendor"))
                    link = os.readlink(os.path.join(path, "driver"))
                except(OSError, IOError):
                    continue
                if None == link or len(link) <= 0:
                    continue
                names = os.path.split(link)
                if None == names or len(names) != 2:
                    continue
                list[names[1]] = item
            return list
        if self._isCmd('lspci'):
            data = _byLsPCI()
        else:
            data = _byListSysDevices()
        return data

    def _getInbandFW(self, list):
        def _getNET():
            for k,v in list.items():
                if (not v.has_key("type")) or (v["type"].lower() != "net"):
                    continue
                for s in os.listdir(os.path.join(v["path"], "net")):
                    p = subprocess.Popen("ethtool -i "+s+" | grep -i \"firmware\"", shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                    out, err = p.communicate()
                    s = str(out)
                    ss = s.split(":")
                    if ss == None or len(ss) != 2:
                        continue
                    ver = ss[1].strip()
                    value = v.copy()
                    value["ver"] = ver
                    value["mode"] = "inband"
                    list[k+"_inband"] = value
            pass
        def _getRAID():
            sas2ircu = sas3ircu = storcli64 = 0
            subprocess.call("chmod +x ../driver/raid/* >/dev/null 2>/dev/null", shell=True)
            for k,v in list.items():
                if (not v.has_key("type")) or (v["type"].lower() != "raid"):
                    continue
                if (k == 'mpt2sas'):
                    s = "../driver/raid/sas2ircu "+str(sas2ircu)+" display|grep -i \"firmware version\"|awk 'BEGAIN{FS=\" \"}{print $4}'"
                    sas2ircu += 1
                elif (k == 'mpt3sas'):
                    s = "../driver/raid/sas3ircu "+str(sas3ircu)+" display|grep -i \"firmware version\"|awk 'BEGAIN{FS=\" \"}{print $4}'"
                    sas3ircu += 1
                elif (k == 'megaraid_sas'):
                    s = "../driver/raid/storcli64  /c"+str(storcli64)+" show|grep -i \"fw version\"|awk 'BEGIN{FS=\" \"}{print $4}'"
                    storcli64 += 1
                else:
                    # unknown type, ignore it!
                    continue
                p = subprocess.Popen(s, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                out, err = p.communicate()
                ver = str(out).strip()
                value = v.copy()
                value["ver"] = ver
                value["mode"] = "inband"
                list[k+"_inband"] = value
            pass
        _getNET()
        _getRAID()
        return

    def _getOutbandFW(self, list):
        # Obtain upgradeable firmware collection resources.
        url = "/redfish/v1/UpdateService/FirmwareInventory"
        resp = self.client.get_resource(url)
        if resp is None or 200 != resp['status_code']:
            return None
        membs = resp['resource']['Members']
        for i in range(0, len(membs)):
            if not membs[i].has_key('@odata.id'):
                continue
            url = membs[i]['@odata.id']
            if url.lower().find('activebmc') >= 0:
                type = "ibmc"
            elif url.lower().find('bios') >= 0:
                type = "bios"
            else:
                continue
            resp = self.client.get_resource(url)
            if None == resp or 200 != resp['status_code']:
                continue
            # name: ver, device, vendor, subsystem_device, subsystem_vendor
            name = resp['resource']['Name']
            value = {}
            value["ver"] = resp['resource']['Version']
            value["mode"] = "outband_"+type
            list[name] = value
        return

    '''
    # Retrieve .repodata/xxx_primary.xml file data as string
    #   It contain all driver's name/version/location/... informations
    '''
    def _getPrimaryXML(self, url):
        s = self._downHttpFileAsString(url + "/repodata/repomd.xml")
        href = None
        try:
            doc = parseString(s)
            try:
                root = doc.documentElement
                datas = root.getElementsByTagName("data") if root else []
                for data in datas:
                    type = data.getAttribute("type")
                    if "primary" != type:
                        continue
                    locas = data.getElementsByTagName("location") if data else []
                    for loca in locas:
                        href = loca.getAttribute("href")
                        break
                    if None != href and len(href) > 0:
                        break
            finally:
                del doc
        except:
            return ''
        s = self._downHttpFileAsString(url + "/" + href)
        return self._unGzData(s)

    '''
    # Filter local driver list by repo server primary.xml
    #   list generate by _getDriverSW and _getInbandFW function
    '''
    def _driverExistsInXML(self, list):
        result = {}
        url = self._getRepoURL()
        xml = self._getPrimaryXML(url)
        if None == xml or len(xml) <= 0:
            self._error(1, "Failed to get primary.xml from reposerver!")
        try:
            doc = parseString(xml)
            try:
                root = doc.documentElement
                for k,v in list.items():
                    vers = []
                    vmax = ""
                    pkgs = root.getElementsByTagName("package") if root else []
                    for pkg in pkgs:
                        nam = pkg.getElementsByTagName("name") if pkg else []
                        if len(nam) <= 0:
                            continue
                        if (k != nam[0].childNodes[0].data) and (("kmod-"+k) != nam[0].childNodes[0].data):
                            continue
                        ver = pkg.getElementsByTagName("version") if pkg else []
                        loc = pkg.getElementsByTagName("location") if pkg else []
                        if len(nam) <= 0 or len(ver) <= 0 or len(loc) <= 0:
                            continue
                        ver = ver[0].getAttribute("ver")
                        loc = loc[0].getAttribute("href")
                        if ver > vmax:
                            vmax = ver
                        vers.append({"version":ver, "location":url+"/"+loc})
                    if len(vers) <= 0:
                        continue
                    vlist2 = []
                    for ver in vers:
                        vlist2.append(ver["version"])
                    result[k] = {"mode":v["mode"], "v-use":v["ver"], "v-max":vmax, "vlist":vlist2, "vlist2":vers}
            finally:
                del doc
        except:
            pass
        return result

    def run(self):
        # Read local all PCI drivers and filter its by driver_version.cfg file
        list = self._getDriverSW()
        vcfg = self._readCfg("driver_version.cfg")
        for k,v in list.items():
            got = False
            if v.has_key("vendor") and v.has_key("device"):
                for row in vcfg:
                    if len(row) < 4:
                        continue
                    if (row[2].lower() == v["vendor"].lower()) and (row[3].lower() == v["device"].lower()):
                        v["type"] = row[1]
                        got = True
                        break
            if not got:
                del list[k]
        # list columns as below:
        #   name: ver, mode, type, path, vendor, device,subsystem_vendor, subsystem_device
        # Add Inband F/W
        self._getInbandFW(list)
        # Add Outband F/W
        self._getOutbandFW(list)
        # Read repo-server filelists
        data = self._driverExistsInXML(list)
        ################################################################################################################
        # test code, need remove its under release mode
        data["raid"] = {"mode":"inband", "v-use":"0.0.011", "v-max":"0.0.013", "v-list":["0.0.012","0.0.013"], "vlist2":[{"version":"0.0.012", "location":"a"},{"version":"0.0.013", "location":"../_/raid.tgz"}]}
        data["bios"] = {"mode":"outband_bios", "v-use":"0.0.011", "v-max":"0.0.013", "v-list":["0.0.012","0.0.013"], "vlist2":[{"version":"0.0.012", "location":"a"},{"version":"0.0.013", "location":"../_/BIOS-10GSFP-1.0.0-1.x86_64.rpm"}]}
        data["ibmc"] = {"mode":"outband_bios", "v-use":"0.0.011", "v-max":"0.0.013", "v-list":["0.0.012","0.0.013"], "vlist2":[{"version":"0.0.012", "location":"a"},{"version":"0.0.013", "location":"../_/BIOS-10GBASE-1.0.0-1.x86_64.rpm"}]}
        ################################################################################################################
        with open("hsu_verify.dat", "wb") as file:
            pickle.dump(data, file)
        for k,v in data.items():
            del v["mode"]
            del v["vlist2"]
        self.result["data"] = data
        return
