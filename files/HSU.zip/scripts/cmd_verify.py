# -*- coding: UTF-8 -*-

import os
import json
import pickle
import subprocess
import ConfigParser
from cmd_base import CmdBase
from cStringIO import StringIO
from xml.dom.minidom import parseString

'''
###############################################################################
# 调用：hsu verify
# 输入：
#   无
# 输出：
#   {
#       "<driver name>":{
#           "v-use":"<current using version>",
#           "v-max":"<server lastest version>",
#           "vlist":["<version-1>", "<version-2>", ...]
#       },
#       ...
#   }
#   name    驱动名称
#   v-use   当前正在使用的版本
#   v-max   服务器上最新的版本
#   vlist   服务器上可用版本列表
###############################################################################
'''
class CmdVerify(CmdBase):
    '''
    # Read repo baseurl from yum repos.d and replace keywords
    '''
    def _getRepoURL(self,firmware=False):
        url = "http://houp.huawei.com/download/server/Linux/Driver/Redhat/Rhel$releasever/$basearch/current/"
        path = "/etc/yum.repos.d"
        if not os.path.isdir(path):
            path = "/etc/yum/repos.d"
        try:
            cp = ConfigParser.ConfigParser()
            cp.read(path+"/houp.repo")
            sect = "huawei-server-driver"
            if firmware:
                sect = "huawei-server-firmware"
            s = cp.get(sect, "baseurl")
        except:
            s = url
        v = self._getOsVer()
        s = s.replace("$releasever", v)
        s = s.replace("$basearch", self._getOsArch())
        return s

    '''
    # Read driver_version.cfg file as table, columns as below:
    #   Device, type, vender_id, device_id, Fw_verion, Driver_name, Driver_version, Driver, sub_vendor_id, sub_system_id
    #   type: net/raid
    '''
    def _readCfg(self,path):
        result = []
        with open(path, "rb") as f:
            while True:
                s = f.readline().strip()
                if len(s) <= 0:
                    break
                s = s.replace('\t', ' ')
                while True:
                    s2 = s.replace('  ', ' ')
                    if len(s) == len(s2):
                        break
                    s = s2
                result.append(s.split(' '))
        return result

    '''
    # Read local PCI driver list, content as below:
    #   name: ver, mode, device, vendor, subsystem_device, subsystem_vendor
    '''
    def _getDriverSW(self):
        list = {}
        p = subprocess.Popen(["find", "/sys/devices/", "-name", "driver"], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        out, err = p.communicate()
        buf = StringIO(out)
        while True:
            s = buf.readline().strip()
            if len(s) <= 0:
                break
            if not s.startswith("/sys/devices/pci"):
                continue
            paths = os.path.split(s)
            if (None == paths) or (len(paths) != 2):
                continue
            path = paths[0]
            item = {"path": path}
            # read device
            try:
                item["ver"] = self._readID(os.path.join(path, "driver/module/version"))
                item["mode"] = "driver"
                item["device"] = self._readID(os.path.join(path, "device"))
                item["vendor"] = self._readID(os.path.join(path, "vendor"))
                item["subsystem_device"] = self._readID(os.path.join(path, "subsystem_device"))
                item["subsystem_vendor"] = self._readID(os.path.join(path, "subsystem_vendor"))
                link = os.readlink(os.path.join(path, "driver"))
            except(OSError, IOError):
                continue
            if None == link or len(link) <= 0:
                continue
            names = os.path.split(link)
            if None == names or len(names) != 2:
                continue
            # maybe use same name in driver and inband firmware, use SW/FW prefix for split them
            list["SW-"+names[1]] = item
        return list

    def _getInbandFW(self, list):
        def _getNET():
            for k,v in list.items():
                if (not v.has_key("type")) or (v["type"].lower() != "net"):
                    continue
                for s in os.listdir(os.path.join(v["path"], "net")):
                    p = subprocess.Popen("ethtool -i "+s+" | grep -i \"firmware\"", shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                    out, err = p.communicate()
                    s = str(out)
                    ss = s.split(":")
                    if ss == None or len(ss) < 2:
                        continue
                    ver = ss[1].strip()
                    value = v.copy()
                    value["ver"] = ver.replace(' ', '.').replace('-', '.')
                    value["mode"] = "inband"
                    list["FW-"+k[3:]] = value
            pass
        def _getDISK():
            subprocess.call("chmod +x ../driver/disktool >/dev/null 2>/dev/null", shell=True)
            result = self._getCmdTable("../driver/disktool -s")
            if None != result and result.has_key("Device"):
                for name in result["Device"]:
                    result2 = self._getCmdPairs("../driver/disktool -f i "+name, ':')
                    if None == result2:
                        continue
                    if not result2.has_key("Device Model"):
                        continue
                    if not result2.has_key("Serial Number"):
                        continue
                    if not result2.has_key("Firmware Version"):
                        continue
                    item = {}
                    item["ver"] = result2["Firmware Version"].replace(' ', '.').replace('-', '.')
                    item["mode"] = "inband"
                    item["type"] = "disk"
                    item["device"] = ''
                    item["vendor"] = ''
                    item["subsystem_device"] = ''
                    item["subsystem_vendor"] = ''
                    list["FW-"+result2["Device Model"]] = item
            pass
        def _getRAID():
            sas2ircu = sas3ircu = storcli64 = 0
            subprocess.call("chmod +x ../driver/raid/* >/dev/null 2>/dev/null", shell=True)
            for k,v in list.items():
                if (not v.has_key("type")) or (v["type"].lower() != "raid"):
                    continue
                if (k == 'SW-mpt2sas'):
                    s = "../driver/raid/sas2ircu "+str(sas2ircu)+" display|grep -i \"firmware version\"|awk 'BEGAIN{FS=\" \"}{print $4}'"
                    sas2ircu += 1
                elif (k == 'SW-mpt3sas'):
                    s = "../driver/raid/sas3ircu "+str(sas3ircu)+" display|grep -i \"firmware version\"|awk 'BEGAIN{FS=\" \"}{print $4}'"
                    sas3ircu += 1
                elif (k == 'SW-megaraid_sas'):
                    s = "../driver/raid/storcli64  /c"+str(storcli64)+" show|grep -i \"fw version\"|awk 'BEGIN{FS=\" \"}{print $4}'"
                    storcli64 += 1
                else:
                    # unknown type, ignore it!
                    continue
                p = subprocess.Popen(s, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                out, err = p.communicate()
                ver = str(out).strip()
                value = v.copy()
                value["ver"] = ver.replace(' ', '.').replace('-', '.')
                value["mode"] = "inband"
                list["FW-"+k[3:]] = value
            pass
        _getNET()
        _getDISK()
        _getRAID()
        return

    def _getOutbandFW(self, list):
        # Obtain upgradeable firmware collection resources.
        url = "/redfish/v1/UpdateService/FirmwareInventory"
        resp = self.client.get_resource(url)
        if resp is None or 200 != resp['status_code']:
            return None
        membs = resp['resource']['Members']
        for i in range(0, len(membs)):
            if not membs[i].has_key('@odata.id'):
                continue
            url = membs[i]['@odata.id']
            if url.lower().find('activebmc') >= 0:
                type = "ibmc"
            elif url.lower().find('bios') >= 0:
                type = "bios"
            else:
                continue
            resp = self.client.get_resource(url)
            if None == resp or 200 != resp['status_code']:
                continue
            # name: ver, device, vendor, subsystem_device, subsystem_vendor
            name = resp['resource']['Name']
            value = {}
            value["ver"] = resp['resource']['Version']
            value["mode"] = "outband"
            value["type"] = type
            value["device"] = ''
            value["vendor"] = ''
            value["subsystem_device"] = ''
            value["subsystem_vendor"] = ''
            list["FW-"+name] = value
        return

    '''
    # Retrieve .repodata/xxx_primary.xml file data as string
    #   It contain all driver's name/version/location/... informations
    '''
    def _getPrimaryXML(self, url):
        s = self._downHttpFileAsString(url + "/repodata/repomd.xml")
        href = None
        try:
            doc = parseString(s)
            try:
                root = doc.documentElement
                datas = root.getElementsByTagName("data") if root else []
                for data in datas:
                    type = data.getAttribute("type")
                    if "primary" != type:
                        continue
                    locas = data.getElementsByTagName("location") if data else []
                    for loca in locas:
                        href = loca.getAttribute("href")
                        break
                    if None != href and len(href) > 0:
                        break
            finally:
                del doc
        except:
            return ''
        s = self._downHttpFileAsString(url + "/" + href)
        return self._unGzData(s)

    def _driverExistsInXML(self, list):
        result = {}
        url = self._getRepoURL()
        xml = self._getPrimaryXML(url)
        if None == xml or len(xml) <= 0:
            self._error(1, "Failed to get primary.xml from driver reposerver!")
        try:
            doc = parseString(xml)
            try:
                root = doc.documentElement
                for k,v in list.items():
                    if not k.startswith("SW-"):
                        continue
                    name = k[3:]
                    vers = []
                    vmax = ""
                    pkgs = root.getElementsByTagName("package") if root else []
                    for pkg in pkgs:
                        nam = pkg.getElementsByTagName("name") if pkg else []
                        if len(nam) <= 0:
                            continue
                        if (name != nam[0].childNodes[0].data) and (("kmod-"+name) != nam[0].childNodes[0].data):
                            continue
                        ver = pkg.getElementsByTagName("version") if pkg else []
                        loc = pkg.getElementsByTagName("location") if pkg else []
                        if len(nam) <= 0 or len(ver) <= 0 or len(loc) <= 0:
                            continue
                        ver = ver[0].getAttribute("ver")
                        loc = loc[0].getAttribute("href")
                        if ver > vmax:
                            vmax = ver
                        vers.append({"version":ver, "location":url+"/"+loc})
                    if len(vers) <= 0:
                        continue
                    vlist2 = []
                    for ver in vers:
                        vlist2.append(ver["version"])
                    result[k] = {"mode":v["mode"], "type":v["type"], "v-use":v["ver"], "v-max":vmax, "vlist":vlist2, "vlist2":vers}
            finally:
                del doc
        except:
            pass
        return result
    def _firmwareExistsInXML(self, list):
        # get server/ibmc unique id by redfish interface
        def _getProductUniqueID():
            ret = self.client.get_resource("/redfish/v1/Managers/1")
            try:
                if None != ret and 200 == ret["status_code"]:
                    return ret["resource"]["Oem"]["Huawei"]["ProductUniqueID"]
            except:
                print("Failed to get ProductUniqueID by /redfish/v1/Managers/1 interface!")
            return None
        uid = _getProductUniqueID()
        result = {}
        url = self._getRepoURL(True)
        xml = self._getPrimaryXML(url)
        if None == xml or len(xml) <= 0:
            self._error(1, "Failed to get primary.xml from firmware reposerver!")
            # test code for houp firmware repo server not ready
            #with open("../driver/f4440b51dad237c1bafb447ee9c90c0903e5d03367a205b614eed328ea466004-primary.xml", "rb") as fp:
            #    xml = fp.read()
        try:
            doc = parseString(xml)
            try:
                root = doc.documentElement
                for k,v in list.items():
                    if not k.startswith("FW-"):
                        continue
                    name = k[3:]
                    vers = []
                    vmax = ""
                    pkgs = root.getElementsByTagName("package") if root else []
                    for pkg in pkgs:
                        nam = pkg.getElementsByTagName("name") if pkg else []
                        if len(nam) <= 0:
                            continue
                        if v["mode"] == "inband":
                            if v["type"] == "disk":
                                if (name != nam[0].childNodes[0].data) and (("kmod-"+name) != nam[0].childNodes[0].data):
                                    continue
                            else:   # net, raid, ...
                                uid = v["vendor"]+"."+v["device"]+"."+v["subsystem_vendor"]+"."+v["subsystem_device"]
                                entries = pkg.getElementsByTagName("rpm:entry") if pkg else []
                                found = False
                                for entry in entries:
                                    s = entry.getAttribute("name")
                                    if s.startswith("SupportModelUID=") and s.find(uid) > 0:
                                        found = True
                                        break
                                if not found:
                                    continue
                        elif v["mode"] == "outband" and uid != None:
                            if nam[0].childNodes[0].data.lower().find(v["type"]) < 0:
                                continue
                            entries = pkg.getElementsByTagName("rpm:entry") if pkg else []
                            found = False
                            for entry in entries:
                                s = entry.getAttribute("name")
                                if s.startswith("SupportModelUID=") and s.find(uid) > 0:
                                    found = True
                                    break
                            if not found:
                                continue
                        else:
                            continue
                        ver = pkg.getElementsByTagName("version") if pkg else []
                        loc = pkg.getElementsByTagName("location") if pkg else []
                        if len(nam) <= 0 or len(ver) <= 0 or len(loc) <= 0:
                            continue
                        ver = ver[0].getAttribute("ver")
                        loc = loc[0].getAttribute("href")
                        if ver > vmax:
                            vmax = ver
                        vers.append({"version":ver, "location":url+"/"+loc})
                    if len(vers) <= 0:
                        continue
                    vlist2 = []
                    for ver in vers:
                        vlist2.append(ver["version"])
                    result[k] = {"mode":v["mode"], "type":v["type"], "v-use":v["ver"], "v-max":vmax, "vlist":vlist2, "vlist2":vers}
            finally:
                del doc
        except:
            pass
        return result

    def run(self):
        # Read local all PCI drivers and filter its by driver_version.cfg file
        list = self._getDriverSW()
        print("=====> Driver List <=====")
        print(json.dumps(list, sort_keys=True, indent=4, separators=(',', ': ')))
        print("=========================")
        vcfg = self._readCfg("driver_version.cfg")
        for k,v in list.items():
            got = False
            if v.has_key("vendor") and v.has_key("device"):
                for row in vcfg:
                    if len(row) < 4:
                        continue
                    if (row[2].lower() == v["vendor"].lower()) and (row[3].lower() == v["device"].lower()):
                        v["type"] = row[1]
                        got = True
                        break
            if not got:
                del list[k]
        print("=====> Filtered by driver_version.cfg <======")
        print(json.dumps(list, sort_keys=True, indent=4, separators=(',', ': ')))
        print("=============================================")
        # list columns as below:
        #   name: ver, mode, type, path, vendor, device,subsystem_vendor, subsystem_device
        # Add Inband F/W
        self._getInbandFW(list)
        print("=====> Append Inband FW List <======")
        print(json.dumps(list, sort_keys=True, indent=4, separators=(',', ': ')))
        print("====================================")
        # Add Outband F/W
        self._getOutbandFW(list)
        print("=====> Append Outband FW List <=====")
        print(json.dumps(list, sort_keys=True, indent=4, separators=(',', ': ')))
        print("====================================")
        # Read repo-server filelists
        sws = self._driverExistsInXML(list)
        print("=====> Filtered by driver repo server primary.xml <=====")
        print(json.dumps(sws, sort_keys=True, indent=4, separators=(',', ': ')))
        print("========================================================")
        fws = self._firmwareExistsInXML(list)
        print("=====> Filtered by firmware repo server primary.xml <=====")
        print(json.dumps(fws, sort_keys=True, indent=4, separators=(',', ': ')))
        print("==========================================================")
        data = {}
        for k,v in sws.items():
            data[k] = v
        for k,v in fws.items():
            data[k] = v
        print("=====> Filtered Results <=====")
        print(json.dumps(data, sort_keys=True, indent=4, separators=(',', ': ')))
        print("==============================")
        ################################################################################################################
        with open("hsu_verify.dat", "wb") as file:
            pickle.dump(data, file)
        for k,v in data.items():
            del v["mode"]
            del v["vlist2"]
        self.result["data"] = data
        return
