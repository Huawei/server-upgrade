# -*- coding: UTF-8 -*-

from cmd_base import CmdBase

'''
#########################################################
# 重启服务器接口
# 调用：hsu restart
##########################################################
'''


class CmdRestart(CmdBase):
    def run(self):
        system_id = "1"
        # get system_id uri
        ret = self.client.get_resource("/redfish/v1/Systems")
        print(ret)
        if None != ret and 200 == ret["status_code"] and len(ret["resource"]["Members"]) > 0:
            system_id = ret["resource"]["Members"][0]["@odata.id"]
        # call force-restart redfish interface
        payload = {"ResetType": "ForceRestart"}
        ret = self.client.create_resource(system_id+"/Actions/ComputerSystem.Reset", payload)
        print(ret)
        if None != ret and 200 == ret["status_code"]:
            pass
        else:
            try:
                self._error(1, ret["message"]["error"]["@Message.ExtendedInfo"][0]["Message"])
            except:
                self._error(2, "Unknown error")
