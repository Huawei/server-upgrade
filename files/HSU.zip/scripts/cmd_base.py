# -*- coding: UTF-8 -*-

import os
import sys
import gzip
import json
import urllib
import urllib2
import subprocess
from cStringIO import StringIO

'''
#=========================================================================
#   @Description: Process user command base class
#		It save user's input arguments and return values
#		Subclass can change the result variable in run function
#		And when this program exit, will print the result to console
#		It's format depend on --format (args.fmt)
#   @author: Joson_Zhang
#   @Date: 2018/06/03
#=========================================================================
'''

class CmdBase:
    import redfish_client

    error = False
    client = redfish_client.RedfishClient()
    flushed = False
    sysstds = [sys.stdout, sys.stderr]

    def __init__(self,args,result):
        self.args = args
        self.result = result
        # redirect stdout and stderr for ignore redfish library print informations
        sys.stdout = open("hsu_stdout.txt", "wb")
        sys.stderr = open("hsu_stderr.txt", "wb")
        # get os info
        dir = self._getOsVer() + '-' + self._getOsArch()
        # install virtual-ethernet driver and startup it
        subprocess.call("insmod ../driver/vnet/" + dir + '/host_cdev_drv.ko >/dev/null 2>/dev/null', shell=True)
        subprocess.call("insmod ../driver/vnet/" + dir + '/host_edma_drv.ko >/dev/null 2>/dev/null', shell=True)
        subprocess.call("insmod ../driver/vnet/" + dir + '/host_veth_drv.ko >/dev/null 2>/dev/null', shell=True)
        subprocess.call("ip link set veth up >/dev/null 2>/dev/null", shell=True)
        # create redfish client object and initialize it
        self.client.create_inner_session()
        self.client.set_inner_bmcinfo()

    def run(self):
        pass

    def __del__(self):
        self._flush()

    def _flush(self):
        if self.flushed:
            return
        self.flushed = True
        self.client.delete_inner_session()
        # rollback standard stdout and stderr
        sys.stdout.close()
        sys.stderr.close()
        sys.stdout = self.sysstds[0]
        sys.stderr = self.sysstds[1]
        # print results
        if True == self.error:
            return
        if "json" == self.args.fmt:
            print(json.dumps(self.result))
        else:
            if 0 == self.result['rc']:
                stat = "Success"
            else:
                stat = "Failure"
            print(" Status: %s" % (stat))
            print("Message: %s" % (self.result["msg"]))
            print("   Data: %s" % str(self.result["data"]))

    def _error(self, rc, msg):
        self.result["rc"] = rc
        self.result["msg"] = msg
        self.result["data"] = {}
        exit(-1)

    def _getName(self, path):
        list = str(path).split('/')
        if list[-1] != path:
            return list[-1]
        return str(path).split("\\")[-1]

    def _isCmd(self, bin):
        p = subprocess.Popen(["which", bin], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        out, err = p.communicate()
        s = str(out).strip()
        if len(s) > 0 and s.find(':') < 0:
            if os.path.exists(s):
                return True
        return False

    def _getOsVer(self):
        def _byLSB():
            p = subprocess.Popen(["lsb_release", "-a"], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            out, err = p.communicate()
            buf = StringIO(out)
            while True:
                s = buf.readline().strip()
                if len(s) <= 0:
                    break
                list = s.split(':')
                if len(list) < 2:
                    continue
                if 'Release' != list[0]:
                    continue
                return list[1].strip()
            return ''
        def _byFile():
            p = subprocess.Popen(["cat", "/etc/redhat-release"], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            out, err = p.communicate()
            # format like this: 'CentOS Linux release 7.4.1708 (Core)'
            s = str(out).strip()
            array = s.split(' ')
            if len(array) > 0:
                for i in range(0, len(array)):
                    if array[i].find('.') < 0:
                        continue
                    array2 = array[i].split('.')
                    if len(array2) < 2:
                        continue
                    return array2[0] + "." + array2[1]
            return ''
        if self._isCmd("lsb_release"):
            s = _byLSB()
        else:
            s = _byFile()
        return s

    def _getOsArch(self):
        p = subprocess.Popen(["arch"], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        out, err = p.communicate()
        return out.replace('\n', '')

    def _readID(self,path):
        s = None
        with open(path, "r") as f:
            s = f.readline()
        if (None != s) and (len(s) > 0):
            #s = s.replace('0x', '')
            s = s.replace('\n', '')
        return s

    def _unGzData(self,data):
        buf = StringIO(data)
        fil = gzip.GzipFile(mode="rb", fileobj=buf)
        try:
            out = fil.read()
        finally:
            fil.close()
        return out

    def _downHttpFile(self,url,path,show_percent=False):
        def _showPercent(got,block,size):
            n = 100.0 * got * block / size
            if n > 100:
                n = 100
            print("Download percent: %.02f%%" % n)
        if False == show_percent:
            urllib.urlretrieve(url, path)
        else:
            urllib.urlretrieve(url, path, _showPercent)

    def _downHttpFileAsString(self,url):
        s = ''
        try:
            f = urllib2.urlopen(url, timeout=10)
            s = f.read()
        except:
            pass
        return s
