# -*- coding: UTF-8 -*-
import time
import traceback
import json

from cmd_progress import CmdProgress
from cmd_upgrade import CmdUpgrade
from cmd_verify import CmdVerify

'''
#########################################################
# 同步升级所有驱动
# 调用：hsu auto-upgrade
#   {
#       "<name>":{
#           "state":"<TaskState>",
#           "percent":<value>
#       },
#       ...
#   }
#   percent 当前升级的百分比，0-100
##########################################################
'''


def is_all_upgrade_completed(results):
    for _, result in results.items():
        if not result or result['state'] != 'Completed':
            return False
    return True


class CmdAutoUpgrade(CmdProgress):

    def run(self):
        # qianbiao.ng: because hsu command does not handle exception,
        # so we re-catch exceptions

        command = None
        try:
            # step1: run verify
            verify_result = {"rc": 0, "msg": "OK", "data": {}}
            command = CmdVerify(self.args, verify_result)
            command.run()
            if verify_result["rc"] != 0:
                self.result = verify_result
                return
            else:
                command.flushed = True
            print("verify result: " + json.dumps(verify_result))

            # step2: run upgrade
            upgrade_result = {"rc": 0, "msg": "OK", "data": {}}
            command = CmdUpgrade(self.args, upgrade_result)
            command.run()
            task_id = upgrade_result["data"]["taskid"]
            print("upgrade result: " + json.dumps(upgrade_result))

            # if task failed or task finished
            if upgrade_result["rc"] != 0 or task_id is None:
                self.result = upgrade_result
                return
            else:
                command.flushed = True

            time.sleep(3)

            # step3: get progress
            while True:
                progress_result = {"rc": 0, "msg": "OK", "data": {}}
                command = CmdProgress(self.args, progress_result)
                task_finished, _ = command.get_task_progress(task_id)
                if task_finished:
                    results = progress_result['data']
                    all_completed = is_all_upgrade_completed(results)
                    if not all_completed:
                        self._error(10, json.dumps(results))
                    self.result = progress_result
                    return
                else:
                    command.flushed = True

                print("task finished: %s, progress result: %s" % (
                    task_finished, progress_result))
                # wait 20 second between query task progress command
                time.sleep(5)

        except Exception as e:
            # disable delegated command's output
            command.flushed = True
            # catch un-handled exceptions, and mark task failed
            traceback.print_exc()
            self._error(10, e.message)
