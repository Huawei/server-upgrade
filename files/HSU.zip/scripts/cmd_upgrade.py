# -*- coding: UTF-8 -*-

import os
import time
import pickle
import subprocess
from cmd_base import CmdBase
from cStringIO import StringIO

'''
###############################################################################
# 调用：hsu upgrade [<name> <version>,...]
# 输入：
#   name    版本比对里面的name
#   version 版本比对里面的version信息，可以是v-max，也可以是vlist里面的任意一个
# 输出：
#   {
#       "taskid":"<task-id>"
#   }
#   taskid  返回的任务id（字符串），如果为空则表示无进度显示（即不需要调用下面的升级进度接口）
# 说明：
#   因为系统分成两种升级方式（yum和ibmc），所以需要分开讨论
#       yum     此种方式是执行yum命令，需要待命令执行完毕才能返回；执行完毕也就意味着升级完毕了，所以无法给出进度提示
#       ibmc    此种方式是将文件下载到本地，然后上传给ibmc，交由ibmc来进行异步升级，所以会返回一个taskid来获取进度信息
###############################################################################
'''

class CmdUpgrade(CmdBase):
    def _uploadFile2BMC(self, path):
        url = "/redfish/v1/UpdateService/FirmwareInventory"
        if not os.path.isfile(path):
            return None
        name = self._getName(path)
        files = {'imgfile': (name, open(path, 'rb'), "multipart/form-data", {'user_name': (self.client.username)})}
        if files is None:
            return None
        resp = self.client.create_resource(url, files=files, timeout=300)
        # Return as below:
        #   {'status_code': 202, 'resource': '{"success":true}', 'headers': {'content-length': '16', ...}}
        if resp is None:
            return None
        if resp['status_code'] != 202:
            return None
        return name

    def _getUpgradeList(self):
        n = len(self.args.options)
        if 0 != (n%2):
            self._error(1, "Invalid argument pair")
            return None
        # Arrange name/version options into K-V map
        kvs = {}
        for i in range(0, len(self.args.options), 2):
            kvs[self.args.options[i]] = self.args.options[i+1]
        # Try load verify command cached data
        try:
            with open("hsu_verify.dat", "rb") as file:
                data = pickle.load(file)
        except:
            self._error(2, "Need run verify first")
            return None
        # Find input name and check it
        kvp = {}
        if len(kvs) > 0:
            for k,v in kvs.items():
                found = False
                for k2,v2 in data.items():
                    if k != k2:
                        continue
                    for item in v2["vlist2"]:
                        if item["version"] != v:
                            continue
                        found = True
                        value = item.copy()
                        value["mode"] = v2["mode"]
                        kvp[k] = value
                        break
                    break
                if not found:
                    self._error(3, "Invalid name (%s) or version (%s)" % (k, v))
                    return None
        else:   # No parameters, means upgrade all verified data
            for k2,v2 in data.items():
                v = v2["v-max"]
                for item in v2["vlist2"]:
                    if item["version"] != v:
                        continue
                    value = item.copy()
                    value["mode"] = v2["mode"]
                    kvp[k2] = value
                    break
        # sort upgrade items, according 2018/06/13 meeting, upgrade follow as below:
        #   driver array
        #   inband array
        #   outband array(3.1 BIOS, 3.2 iBMC)
        result = {}
        items = []
        for k,v in kvp.items():
            if v["mode"] == "driver":
                item = {"name":k, "version":v["version"], "location":v["location"]}
                items.append(item)
        if len(items) > 0:
            result["driver"] = items
        items = []
        for k,v in kvp.items():
            if v["mode"] == "inband":
                item = {"name":k, "version":v["version"], "location":v["location"]}
                items.append(item)
        if len(items) > 0:
            result["inband"] = items
        items = []
        for k,v in kvp.items():
            if v["mode"] == "outband_bios":
                item = {"name":k, "version":v["version"], "location":v["location"]}
                items.append(item)
        for k,v in kvp.items():
            if v["mode"] == "outband_ibmc":
                item = {"name":k, "version":v["version"], "location":v["location"]}
                items.append(item)
        if len(items) > 0:
            result["outband"] = items
        return result

    def _upgradeDriver(self, item, elist):
        self._downHttpFile(item["location"], "hsu_upgrade.rpm")
        p = subprocess.Popen("rpm -i hsu_upgrade.rpm", shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        # rc = subprocess.call("rpm --force --nodeps -i hsu_upgrade.rpm > /dev/null 2>/dev/null", shell=True)
        out, err = p.communicate()
        if 0 != p.returncode:
            elist[item["name"]] = str(out).strip()
            return False
        return True

    def _inbandGetBaseURI(self):
        url = "/redfish/v1" + "/Managers"
        ret = self.client.get_resource(url)
        if None != ret and 200 == ret["status_code"] and len(ret["resource"]["Members"]) > 0:
            return ret["resource"]["Members"][0]["@odata.id"]
        return None
    def _inbandSetSPService(self, spEnable, restartTimeout=30, deployTimeout=7200, deployStatus=True):
        url = self._inbandGetBaseURI() + "/SPService"
        # Get/Update If-Match value
        self.client.get_resource(url)
        payload = {"SPStartEnabled":spEnable , "SysRestartDelaySeconds":restartTimeout, "SPTimeout":deployTimeout, "SPFinished":deployStatus}
        ret = self.client.set_resource(url, payload)
        if None != ret and 200 == ret["status_code"]:
            return True
        return False
    def _inbandGetFwUpdateURI(self):
        url = self._inbandGetBaseURI() + "/SPService/SPFWUpdate"
        ret = self.client.get_resource(url)
        if None != ret and 200 == ret["status_code"] and len(ret["resource"]["Members"]) > 0:
            return ret["resource"]["Members"][0]["@odata.id"]
        return None

    def upgradeInbandFW(self, base, item, elist):
        url = base + "/Actions/SPFWUpdate.SimpleUpdate"
        subprocess.call("rm -rf tmp && mkdir tmp >/dev/null 2>/dev/null", shell=True)
        self._downHttpFile(item["location"], "tmp/hsu_upgrade.rpm")
        # for tgz test only!!!
        if (item["location"].lower().endswith(".tgz")):
            cmd = "cd tmp && tar -xvzf hsu_upgrade.rpm"
        else:
            cmd = "cd tmp && rpm2cpio hsu_upgrade.rpm | cpio -div"
        p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        out, err = p.communicate()
        buf = StringIO(out)
        zip = asc = ""
        while True:
            s = buf.readline().strip()
            if len(s) <= 0:
                break
            s = "tmp/" + s
            if s.lower().endswith(".zip"):
                zip = s
            elif s.lower().endswith(".asc"):
                asc = s
        if len(zip) <= 0 or len(asc) <= 0:
            elist[item["name"]] = "Not found zip or asc in rpm file"
            return None
        nzip = self._uploadFile2BMC(zip)
        if None == nzip:
            elist[item["name"]] = "Failed to upload zip file"
            return None
        nasc = self._uploadFile2BMC(asc)
        if None == nasc:
            elist[item["name"]] = "Failed to upload asc file"
            return None
        payload = {'ImageURI': ('file:///tmp/web/' + nzip), "SignalURI": ('file:///tmp/web/' + nasc),
                   "ImageType": "Firmware", "Parameter": "all", "UpgradeMode": "Recover", "ActiveMethod": "OSRestart"}
        resp = self.client.create_resource(url, payload, timeout=20)
        # Return as below:
        #   {'status_code': 202, 'resource': {u'@odata.type': u'#Task.v1_0_2.Task', u'Name': u'Upgarde Task',
        #   u'TaskState': u'Running', u'Messages': [], u'@odata.id': u'/redfish/v1/TaskService/Tasks/2',
        #   u'@odata.context': u'/redfish/v1/$metadata#TaskService/Tasks/Members/$entity',
        #   u'StartTime': u'2018-06-26T02:47:16+00:00', u'Id': u'2',
        #   u'Oem': {u'Huawei': {u'TaskPercentage': None}}}, 'headers': {'content-length': '315', ...}}
        if None == resp or 200 != resp["status_code"]:
            elist[item["name"]] = "Failed to upgrade inband FW"
            return False
        return True

    def upgradeOutbandFW(self, item, elist):
        url = "/redfish/v1/UpdateService/Actions/UpdateService.SimpleUpdate"
        subprocess.call("rm -rf tmp && mkdir tmp >/dev/null 2>/dev/null", shell=True)
        self._downHttpFile(item["location"], "tmp/hsu_upgrade.rpm")
        cmd = "cd tmp && rpm2cpio hsu_upgrade.rpm | cpio -div"
        p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        out, err = p.communicate()
        buf = StringIO(out)
        hpm = ""
        while True:
            s = buf.readline().strip()
            if len(s) <= 0:
                break
            s = "tmp/" + s
            if s.lower().endswith(".hpm"):
                hpm = s
        if len(hpm) <= 0:
            elist[item["name"]] = "Not found hpm in rpm file"
            return None
        nhpm = self._uploadFile2BMC(hpm)
        if None == nhpm:
            elist[item["name"]] = "Failed to upload hpm file"
            return None
        payload = {'ImageURI': ('/tmp/web/' + nhpm)}
        resp = self.client.create_resource(url, payload, timeout=20)
        # Return as below:
        #   {'status_code': 202, 'resource': {u'@odata.type': u'#Task.v1_0_2.Task', u'Name': u'Upgarde Task',
        #   u'TaskState': u'Running', u'Messages': [], u'@odata.id': u'/redfish/v1/TaskService/Tasks/2',
        #   u'@odata.context': u'/redfish/v1/$metadata#TaskService/Tasks/Members/$entity',
        #   u'StartTime': u'2018-06-26T02:47:16+00:00', u'Id': u'2',
        #   u'Oem': {u'Huawei': {u'TaskPercentage': None}}}, 'headers': {'content-length': '315', ...}}
        if 202 != resp["status_code"]:
            msg = 'Unknown'
            if resp.has_key("resource") and resp["resource"].has_key("Message"):
                msg = resp["resource"]["Message"]
            elist[item["name"]] = "Failed to upgrade outband FW: "+msg
            return None
        return resp["resource"]["@odata.id"]

    def run(self):
        # Collect upgrade list and sort it by rules
        data = self._getUpgradeList()
        if None == data:
            return
        # Enter install step
        try:
            # Calculate all update counts
            n = 0
            if data.has_key("driver"):
                n += len(data["driver"])
            if data.has_key("inband"):
                n += len(data["inband"])
            if data.has_key("outband"):
                n += len(data["outband"])
            # upgrade drivers and remove it from list
            item = {}
            done = []
            elist = {}
            taskid = None
            bHasSuccess = False
            bNeedResetOS = False
            if data.has_key("driver"):      # Upgrade driver(s) if exists
                for item in data["driver"]:
                    if self._upgradeDriver(item, elist):
                        bHasSuccess = True
                        done.append({"name":item["name"], "state":"Completed"})
                    else:
                        done.append({"name":item["name"], "state":"Exception"})
            if data.has_key("inband"):      # Upgrade Inband FW(s) if exists
                sBaseURI = self._inbandGetFwUpdateURI()
                bNeedResetOS = self._inbandSetSPService(True)
                for item in data["inband"]:
                    if None != sBaseURI and bNeedResetOS:
                        if self.upgradeInbandFW(sBaseURI, item, elist):
                            bHasSuccess = True
                            done.append({"name":item["name"], "state":"Completed"})
                        else:
                            done.append({"name":item["name"], "state":"Exception"})
                    else:
                        # Failed to enable SP, ignore all inband FW upgrade
                        done.append({"name": item["name"], "state": "Interrupted"})
            if data.has_key("outband"):     # Upgrade first Outband FW if exists until OK
                while len(data["outband"]) > 0:
                    item = data["outband"][0]
                    data["outband"].remove(item)
                    taskid = self.upgradeOutbandFW(item, elist)
                    if None != taskid:
                        bHasSuccess = True
                        break
                    else:
                        done.append({"name": item["name"], "state": "Exception"})
            id = time.strftime("%Y%m%d%H%M%S")
            if None != taskid:
                body = {"taskid":id, "n":n, "data":data, "done":done, "progid":taskid, "progname":item["name"], "resetos":bNeedResetOS}
                with open("hsu_upgrade.dat", "wb") as file:
                    pickle.dump(body, file)
            if None != taskid and bHasSuccess:
                data = {"taskid":id}
                if len(elist) > 0:
                    data["message"] = "Failed to install %s package(s): %s" % (str(elist.keys()), str(elist.values()))
                self.result["data"] = data
            else:
                self._error(9, "Failed to install %s package(s): %s" % (str(elist.keys()), str(elist.values())))
        finally:
            subprocess.call("rm -rf tmp >/dev/null 2>/dev/null", shell=True)
            subprocess.call("rm -rf hsu_verify.dat >/dev/null 2>/dev/null", shell=True)
            subprocess.call("rm -rf hsu_upgrade.rpm >/dev/null 2>/dev/null", shell=True)
