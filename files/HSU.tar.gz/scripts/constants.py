#   Licensed under the Apache License, Version 2.0 (the "License"); you may
#   not use this file except in compliance with the License. You may obtain
#   a copy of the License at
#
#        http://www.apache.org/licenses/LICENSE-2.0
#
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#   WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#   License for the specific language governing permissions and limitations
#   under the License.
#
MODE_DRIVER = "driver"
MODE_INBAND = "inband"
MODE_OUTBAND = "outband"

PREF_DRIVER = "Drv-"
PREF_FIRMWARE = "FW-"

RESULT_COMPLETE = "Completed"
RESULT_FAILED = "Exception"

TYPE_BIOS = "bios"
TYPE_BMC = "ibmc"

TO_BIOS = 1500
TO_BMC = 900
TO_BMC_RESTART = 360

ODATA_ID_KEY = "@odata.id"
SPT_MODEL_UID_KEY = "SupportModelUID="

DFT_RHEL_REPO_URL = ("http://houp.huawei.com/download/server/Linux/Driver"
                     "/Redhat/Rhel$releasever/$basearch/current/")
