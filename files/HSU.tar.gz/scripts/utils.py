#   Licensed under the Apache License, Version 2.0 (the "License"); you may
#   not use this file except in compliance with the License. You may obtain
#   a copy of the License at
#
#        http://www.apache.org/licenses/LICENSE-2.0
#
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#   WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#   License for the specific language governing permissions and limitations
#   under the License.
#
import os
from string import lower

from datetime import datetime

from constants import *

pidfile = "/tmp/hsu-tool.pid"


def now():
    return str(datetime.now().strftime("%Y-%m-%d %H:%M:%S"))


def create_pidfile():
    """
    create a pidfile for current progress
    :return: True if created, False if exists
    """
    if os.path.isfile(pidfile):
        print ("[%s] pidfile %s already exists" % (now(), pidfile))
        # if pidfile exists, then check if pid really running
        pid = open(pidfile, "r").read()
        if is_running(pid):
            print ("[%s] pidfile exists, pid is running" % now())
            return False
        else:
            print ("[%s] pid not exist, pidfile removed" % now())
            os.unlink(pidfile)

    pid = str(os.getpid())
    file(pidfile, 'w').write(pid)
    print ("[%s] pidfile %s created" % (now(), pidfile))
    return True


def remove_pidfile():
    print ("[%s] pidfile %s removed" % (now(), pidfile))
    os.unlink(pidfile)


def is_running(pid):
    return os.path.isdir('/proc/{}'.format(pid))


def get_success_msg(item):
    name = item["name"]
    version = item["version"]
    message = "`%s` upgrade to version `%s` successful" % (name, version)
    return {
        "name": name,
        "state": RESULT_COMPLETE,
        "message": message,
        "package": item["location"]
    }


def get_failed_msg(item, message=None):
    name = item["name"]
    version = item["version"]
    dft_message = "Failed to upgrade `%s` to version `%s`" % (name, version)
    return {
        "name": name,
        "state": RESULT_FAILED,
        "message": message if message else dft_message,
        "package": item["location"]
    }


def should_upgrade_item(item):
    """should upgrade item according to item's mode & max-version
    & current-version
    :param item:
    :return: True if upgrade else not upgrade
    """
    max_version = item["v-max"]
    current_version = item["v-use"]
    mode = item["mode"]
    if mode == MODE_DRIVER:
        return max_version > current_version
    if mode == MODE_OUTBAND:
        return max_version > current_version
    if mode == MODE_INBAND:
        return max_version != current_version


def is_installed(installed_list, item):
    """checking is an item installed according to whether the item's install
    package download url has exits in the installed item list
    :param installed_list: a list of object : {
        "name": name,
        "state": RESULT_COMPLETE,
        "message": message,
        "package": package download url
    }
    :param item:
    :return:
    """
    item_name = item["name"]
    item_package_url = item["location"]

    print("[%s] checked whether item %s installed" % (now(), item_name))
    for installed in installed_list:
        if installed["package"] == item_package_url:
            if installed["state"] == RESULT_COMPLETE:
                result = get_success_msg(item)
            else:
                result = get_failed_msg(item, installed["message"])

            print("[%s] item %s installed" % (now(), item_name))
            print("[%s] result diff, old %s, new %s" % (
                now(), installed, result))
            return True, result

    print("[%s] item %s not installed" % (now(), item_name))
    return False, None


def drv_list_2_map(driver_list):
    """convert a driver list to map with name as key
    :param driver_list:
    :param key:
    :return:
    """
    mapped = {}

    unique_driver_mapping = {}
    names = []
    for driver in driver_list:
        if lower(driver["device"]) == "0x37d1":
            continue
        key = "|".join([driver["device"],
                        driver["vendor"],
                        driver["subsystem_device"],
                        driver["subsystem_vendor"]])
        if key not in unique_driver_mapping:
            unique_driver_mapping[key] = driver
            names.append(driver["name"])

    unique_driver_list = unique_driver_mapping.values()
    for driver in unique_driver_list:
        name = driver["name"]
        count = names.count(name)
        if count == 1:
            mapped[name] = driver
        else:
            bdf = driver["path"].split("/")[-1]
            mapped["%s@%s" % (name, bdf)] = driver

    return mapped


def get_driver_configs():
    """ parse driver_name.cfg into an object array which contains Object like:
    #   Device  type  vender_id device_id  Driver  sub_vendor_id   sub_system_id
    :return:
    """
    with open("../config/driver_name.cfg", "rb") as f:
        return [line.strip().split() for line in f.readlines() if len(line) > 1]


def init_default_houp_repo():
    """copy config/houp.os.repo file to os yum repo folder if not exists
    :return:
    """
    yum_repo_path = "/etc/yum.repos.d"
    if not os.path.isdir(yum_repo_path):
        yum_repo_path = "/etc/yum/repos.d"
    target_houp_repo_path = os.path.join(yum_repo_path, "houp.repo")
    if not os.path.exists(target_houp_repo_path):
        print("houp repo not found in %s, create default now" % yum_repo_path)
        import platform
        import shutil
        distribution = platform.linux_distribution()[0]
        if "CentOS" in distribution:
            shutil.copy2("../config/houp.centos.repo",
                         target_houp_repo_path)
        elif "Red Hat" in distribution:
            shutil.copy2("../config/houp.rhel.repo",
                         target_houp_repo_path)
