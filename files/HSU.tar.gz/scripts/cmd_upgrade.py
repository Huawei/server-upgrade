# -*- coding: UTF-8 -*-
import json
import sys
import time
import traceback

import utils

reload(sys)
sys.setdefaultencoding('UTF-8')

from cmd_progress import CmdProgress
from cmd_sync_upgrade import CmdUpgrade
from cmd_verify import CmdVerify

'''
#########################################################
# 同步升级所有驱动
# 调用：hsu auto-upgrade
#   {
#       "<name>":{
#           "state":"<TaskState>",
#           "percent":<value>
#       },
#       ...
#   }
#   percent 当前升级的百分比，0-100
##########################################################
'''


def is_all_upgrade_completed(results):
    for _, result in results.items():
        if not result or result['state'] != 'Completed':
            return False
    return True


class CmdAutoUpgrade(CmdProgress):
    def run(self):
        # qianbiao.ng: because hsu command does not handle exception,
        # so we re-catch exceptions

        print("+------------------------------------------------+")
        print("[%s] Start auto upgrade job now " % (utils.now()))
        print("+------------------------------------------------+")

        command = None
        pidfile_created = False
        try:
            # create pidfile for current progress
            pidfile_created = utils.create_pidfile()
            if not pidfile_created:
                msg = "Other upgrade task is running now, " \
                      "please wait until it finished"
                self._error(1, msg)
                return

            # step1: run verify
            verify_result = {"rc": 0, "msg": "OK", "data": {}}
            command = CmdVerify(self.args, verify_result)
            command.run()
            if verify_result["rc"] != 0:
                self.result = verify_result
                return
            else:
                command.flushed = True
            print("[%s] verify result: %s" % (utils.now(),
                                              json.dumps(verify_result)))

            # step2: run upgrade
            # remove auto option to keep back compatibility
            if len(self.args.options) == 1 and self.args.options[0] == "auto":
                self.args.options.pop(0)

            upgrade_result = {"rc": 0, "msg": "OK", "data": {}}
            command = CmdUpgrade(self.args, upgrade_result)
            command.run()
            task_id = upgrade_result["data"]["taskid"]
            print("[%s] upgrade result: %s" % (utils.now(),
                                               json.dumps(upgrade_result)))

            # no_task = task_id is None or len(task_id) == 0
            # if task failed or task finished
            if upgrade_result["rc"] != 0:
                self.result = upgrade_result
                return
            else:
                command.flushed = True

            time.sleep(3)

            progress_result = {"rc": 0, "msg": "OK", "data": {}}
            command = CmdProgress(self.args, progress_result)
            # step3: get progress
            while True:
                command.flushed = False
                command.error = False
                task_finished, _ = command.get_task_progress(task_id)
                print("[%s] task finished: %s, progress result: %s" % (
                    utils.now(), task_finished, progress_result))
                if task_finished:
                    results = progress_result['data']
                    all_completed = is_all_upgrade_completed(results)
                    if not all_completed:
                        self._error(10, json.dumps(results))
                    self.result = progress_result

                    print("[%s] auto upgrade final result: %s" % (
                        utils.now(), json.dumps(progress_result)))
                    print("[%s] auto upgrade job finished " % (utils.now()))
                    print("\n".join([" " for i in range(1, 10)]))
                    return
                else:
                    command.flushed = True

                # wait 20 second between query task progress command
                time.sleep(10)
        except Exception as e:
            # disable delegated command's output
            command.flushed = True
            # catch un-handled exceptions, and mark task failed
            traceback.print_exc()
            self._error(10, e.message)
        finally:
            # remove pid file
            if pidfile_created:
                utils.remove_pidfile()
