# -*- coding: UTF-8 -*-

import pickle
import subprocess
import time

from cmd_sync_upgrade import CmdUpgrade
from utils import *

'''
###############################################################################
# Call method：hsu progress <task-id>
# Input：
#   task-id hsu upgrade return taskid
# Output：
#   {
#       "<name>":{
#           "state":"<TaskState>",
#           "percent":<value>
#       },
#       ...
#   }
#   state   see redfish API document
#   percent 0-100
###############################################################################
'''


class CmdProgress(CmdUpgrade):
    # get task progress info by redfish interface
    def query_single_task_progress(self, upgrading, max_wait_sec=300):
        result = get_failed_msg(upgrading)
        result["percent"] = 100

        start_on = time.time()
        while True:
            if (time.time() - start_on) >= max_wait_sec:
                break
            resp = self.client.get_resource(upgrading["task_id"])
            if resp is None:  # Network not ready? need try again and again ...
                time.sleep(1)
                continue
            print(resp)
            # or "Exception" == resp['resource']['TaskState']:
            if 200 != resp["status_code"]:
                break
            if RESULT_COMPLETE == resp['resource']['TaskState']:
                result = get_success_msg(upgrading)
                result["percent"] = 100
                break
            progress = 0
            try:
                percent = resp['resource']['Oem']['Huawei']['TaskPercentage']
                percent = percent.replace("%", "")
                progress = int(percent)
                if progress >= 100:  # check the task is done?
                    progress = 99
            except:
                # maybe percent value is None, it will cause exception here!!!
                pass
            result["state"] = resp['resource']['TaskState']
            result["percent"] = progress
            break
        return result

    def run(self):
        if len(self.args.options) < 1:
            self._error(1, "Usage: hsu progress <task-id>")
            return
        taskid = self.args.options[0]
        task_finished, reset_os = self.get_task_progress(taskid)
        if task_finished and reset_os:
            self._flush()
            # Need reboot X86 OS for active inband upgrades
            print("Rebooting X86 OS, need remove it under release mode!!!")
            # subprocess.call("reboot >/dev/null 2>/dev/null", shell=True)

    def compare_bmc_version(self, item):
        """compare current bmc version with item's expect version

        :param item:
        :return: true if version equals else false
        """
        current_time = time.time()
        get_bmc_url = "/redfish/v1/UpdateService/FirmwareInventory/ActiveBMC"
        while time.time() - current_time < TO_BMC_RESTART:
            try:
                response = self.client.get_resource(get_bmc_url)
                if "Version" in response:
                    return item["version"] == response["Version"]
            except Exception as e:
                print("Failed to get BMC version, reason: " + str(e))
            time.sleep(2)

    def get_task_progress(self, taskid):
        # Load cached tasks info
        try:
            with open("hsu_upgrade.dat", "rb") as f:
                data = pickle.load(f)
            if data["taskid"] != taskid:
                raise Exception("Invalid taskid")
        except:
            self._error(2, "Invalid taskid, need run verify and upgrade again")
            return

        progress = {}  # progress item
        is_updating = False  # identify any firmware is updating
        if "upgrading" in data and "task_id" in data["upgrading"]:
            # Retrieve current upgrading item state and percentage
            upgrading_item = data["upgrading"]

            # timeout validation
            item_type = upgrading_item["type"]
            cost_seconds = time.time() - upgrading_item["start_on"]
            if item_type == TYPE_BIOS:
                timeout = TO_BIOS
            elif item_type == TYPE_BMC:
                timeout = TO_BMC
            if timeout is not None and cost_seconds > timeout:
                message = "operation timeout, limit %ds" % timeout
                data["done"].append(get_failed_msg(upgrading_item, message))
                data.pop("upgrading", None)
            else:
                result = self.query_single_task_progress(upgrading_item)
                is_updating = (result["percent"] < 100)
                if not is_updating:
                    data.pop("upgrading", None)
                    success = result["state"] = RESULT_COMPLETE
                    # when bmc upgrade success, compare bmc version
                    if item_type == TYPE_BMC and success:
                        version_match = self.compare_bmc_version()
                        data["done"].append(result if version_match else
                                            get_failed_msg(upgrading_item))
                    else:
                        data["done"].append(result)
                else:
                    progress[result["name"]] = {"state": result["state"],
                                                "message": result["message"],
                                                "percent": result["percent"]}

        items = data["data"]
        if MODE_OUTBAND not in data["data"]:
            items[MODE_OUTBAND] = []

        # if no item is upgrading and got items to be upgraded
        has_outband_item = len(items[MODE_OUTBAND]) > 0
        while not is_updating and has_outband_item:
            failed_msg = {}
            item = items[MODE_OUTBAND][0]
            items[MODE_OUTBAND].remove(item)

            # check whether the item has been upgraded
            installed, result = is_installed(data["done"], item)
            if installed:
                data["done"].append(result)
                continue

            start_on = time.time()  # task start on(used for timeout checking)
            taskid = self.upgradeOutbandFW(item, failed_msg)
            if taskid is None:  # failed
                message = failed_msg[item["name"]]
                data["done"].append(get_failed_msg(item, message))
            else:  # mark current item as upgrading
                upgrading = item.copy()
                upgrading["start_on"] = start_on  # upgrading start on
                upgrading["task_id"] = taskid
                data["upgrading"] = upgrading
                progress[item["name"]] = {"state": "Running",
                                          "message": "Running",
                                          "percent": 0}
                break

        # 添加已完成升级进度列表
        # add finished item's progress
        for item in data["done"]:
            progress[item["name"]] = {"state": item["state"],
                                      "message": item["message"],
                                      "percent": 100}

        # add pending item's progress
        if MODE_OUTBAND in items:
            for item in items[MODE_OUTBAND]:
                progress[item["name"]] = {"state": "Pending",
                                          "message": "Pending",
                                          "percent": 0}

        # checking whether all item has be processed
        finished = (not is_updating
                    and ("upgrading" not in data or data["upgrading"] is None)
                    and len(items[MODE_OUTBAND]) == 0)
        if finished:
            subprocess.call("rm -rf tmp >/dev/null 2>/dev/null", shell=True)
            subprocess.call("rm -rf hsu_upgrade.dat >/dev/null 2>/dev/null",
                            shell=True)
        else:
            with open("hsu_upgrade.dat", "wb") as f:
                pickle.dump(data, f)
        self.result["data"] = progress
        return finished, data["resetos"]
