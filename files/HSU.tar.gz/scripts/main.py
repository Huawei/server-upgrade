#!/usr/bin/python
# -*- coding: UTF-8 -*-

import argparse
import os
import signal
import sys

__version__ = '1.0.0'


def doit():
    # ================================================================
    # @Method:  CLI main entry function
    # @Param:   None
    # @Return:  None
    # @Author:  Joson_Zhang
    # ================================================================
    try:
        # Construct argparser and add major command parameters.
        parser = argparse.ArgumentParser(prog='hsu')
        parser.add_argument('-v', '--version', action='version',
                            version="Version: %s" % __version__)
        parser.add_argument('--format', dest="fmt", choices=['json', 'console'],
                            default="console",
                            help="output format type (console, json)")
        parser.add_argument('command', metavar='command',
                            choices=['verify', 'upgrade', 'restart'],
                            help="command (verify, upgrade, restart)")
        parser.add_argument('options', metavar='options', nargs='*',
                            help="run %(prog)s command for detail help")
        args = parser.parse_args()

        # qianbiao.ng: make command to support "-""
        cmd = __import__('cmd_' + args.command.replace('-', "_"))
        capitalize_cmd = ''.join(
            x.capitalize() or '_' for x in args.command.split('-'))
        cls = getattr(cmd, 'Cmd' + capitalize_cmd)

        obj = cls(args, {"rc": 0, "msg": "OK", "data": {}})
        obj.run()
    except KeyboardInterrupt:
        s = signal.signal(signal.SIGINT, signal.SIG_IGN)
        signal.signal(signal.SIGINT, s)


if __name__ == '__main__':
    root = os.path.split(os.path.realpath(__file__))[0]
    os.chdir(root)
    sys.path.insert(1, os.path.join(root, '../third-party'))
    doit()
